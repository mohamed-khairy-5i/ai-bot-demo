/* حافظ التابات — منطق البوب أب */
const $ = (s, el = document) => el.querySelector(s);
let SESSIONS = [];
let EXPANDED = new Set();
let FILTER = '';

const esc = (t) => (t || '').replace(/[&<>"']/g, (c) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[c]));

const host = (u) => {
  try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return (u || '').slice(0, 42); }
};

function fmtDate(ts) {
  const d = new Date(ts);
  const day = d.toLocaleDateString('ar-EG', { day: 'numeric', month: 'long' });
  const time = d.toLocaleTimeString('ar-EG', { hour: 'numeric', minute: '2-digit' });
  return day + ' · ' + time;
}

/* ── التقاط التابات المفتوحة ── */
async function captureOpenTabs() {
  const tabs = await chrome.tabs.query({});
  const seen = new Set(); const saved = []; const ids = [];
  for (const t of tabs) {
    const u = t.url || t.pendingUrl || '';
    if (!/^(https?|file):/i.test(u)) continue; // نتجاهل صفحات كروم الداخلية
    if (seen.has(u)) continue; seen.add(u);
    saved.push({ title: t.title || u, url: u, favIconUrl: /^https?:/i.test(t.favIconUrl || '') ? t.favIconUrl : '' });
    ids.push(t.id);
  }
  return { saved, ids };
}

/* ── الرسم ── */
function render() {
  const list = $('#sessions');
  const q = FILTER.trim().toLowerCase();
  let shown = 0;

  const html = SESSIONS.map((s) => {
    const tabs = s.tabs.filter((t) =>
      !q || (t.title || '').toLowerCase().includes(q) || (t.url || '').toLowerCase().includes(q));
    if (q && !tabs.length) return '';
    shown++;
    const open = EXPANDED.has(s.id);
    return `
    <section class="session ${open ? 'open' : ''}" data-id="${s.id}">
      <div class="s-head">
        <span class="chev">▾</span>
        <div class="s-name">${esc(s.name)}</div>
        <span class="count">${s.tabs.length} تاب</span>
        <div class="s-actions">
          <button class="mini go" data-act="openall" title="افتح كل تابات المجموعة">افتح الكل</button>
          <button class="mini add" data-act="add" title="ضيف التابات المفتوحة دلوقتي للمجموعة دي">+</button>
          <button class="mini ren" data-act="ren" title="غيّر اسم المجموعة">✎</button>
          <button class="mini del" data-act="del" title="امسح المجموعة">🗑</button>
        </div>
      </div>
      <div class="s-date">${fmtDate(s.created)}</div>
      <div class="s-tabs">
        ${tabs.map((t) => `
          <div class="tabrow" data-url="${esc(t.url)}" title="دوس لفتح التاب">
            <span class="favw">${t.favIconUrl ? `<img src="${esc(t.favIconUrl)}" alt="">` : ''}<i>${esc((t.title || '؟').trim()[0] || '؟')}</i></span>
            <div class="tmeta">
              <div class="ttitle">${esc(t.title || t.url)}</div>
              <div class="thost">${esc(host(t.url))}</div>
            </div>
            <button class="mini x" data-act="rmtab" title="شيله من المجموعة">✕</button>
          </div>`).join('')}
      </div>
    </section>`;
  }).join('');

  list.innerHTML = html ||
    (q
      ? `<div class="empty">مفيش نتيجة للبحث «${esc(FILTER)}»</div>`
      : `<div class="empty">🗂️ مفيش أي حاجة محفوظة لسه<br><small>دوس «احفظ كل التابات» فوق — والمتصفح هيبقى نضيف فورًا</small></div>`);
}

/* ── Toast ── */
let toastTimer = null;
function flash(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2300);
}

/* ── الحفظ ── */
$('#saveAll').addEventListener('click', async () => {
  const { saved, ids } = await captureOpenTabs();
  if (!saved.length) { flash('مفيش تابات مواقع أقدر أحفظها'); return; }
  const s = { id: 's' + Date.now(), name: 'جلسة ' + fmtDate(Date.now()), created: Date.now(), tabs: saved };
  SESSIONS.unshift(s);
  EXPANDED.add(s.id);
  await chrome.storage.local.set({ sessions: SESSIONS });
  if ($('#closeAfter').checked && ids.length) {
    try {
      await chrome.tabs.create({ active: false }); // نسيب تاب واحد عشان النافذة متقفلش قبل ما نمسح
      await chrome.tabs.remove(ids);
    } catch (e) { /* لو البوب أب اتقفل خلاص الحفظ اتم قبل كده */ }
  }
  render();
  flash(`تم حفظ ${saved.length} تاب — المتصفح بقى نضيف`);
});

$('#saveCurrent').addEventListener('click', async () => {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  const u = (t && (t.url || t.pendingUrl)) || '';
  if (!/^https?:/i.test(u)) { flash('التاب ده مش موقع عادي'); return; }
  let s = SESSIONS.find((x) => x.id === 'inbox');
  if (!s) {
    s = { id: 'inbox', name: 'تابات مفردة', created: Date.now(), tabs: [] };
    SESSIONS.unshift(s);
  }
  if (!s.tabs.some((x) => x.url === u)) {
    s.tabs.unshift({ title: t.title || u, url: u, favIconUrl: /^https?:/i.test(t.favIconUrl || '') ? t.favIconUrl : '' });
  }
  EXPANDED.add('inbox');
  await chrome.storage.local.set({ sessions: SESSIONS });
  render();
  flash('اتحفظ في «تابات مفردة»');
});

/* ── تفاعلات القايمة ── */
$('#sessions').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-act]');
  const sec = e.target.closest('.session');
  if (!sec) return;
  const s = SESSIONS.find((x) => x.id === sec.dataset.id);
  if (!s) return;

  if (btn) {
    const act = btn.dataset.act;

    if (act === 'openall') {
      for (const t of s.tabs) {
        try { await chrome.tabs.create({ url: t.url, active: false }); } catch (err) {}
      }
      flash(`فتحت ${s.tabs.length} تاب`);
      return;
    }

    if (act === 'add') {
      const { saved } = await captureOpenTabs();
      const have = new Set(s.tabs.map((t) => t.url));
      let added = 0;
      for (const t of saved) {
        if (!have.has(t.url)) { s.tabs.push(t); have.add(t.url); added++; }
      }
      await chrome.storage.local.set({ sessions: SESSIONS });
      EXPANDED.add(s.id);
      render();
      flash(added ? `ضفت ${added} تاب جديد للمجموعة` : 'مفيش تابات جديدة تتضاف');
      return;
    }

    if (act === 'del') {
      if (!btn.classList.contains('armed')) {
        btn.classList.add('armed');
        btn.textContent = 'متأكد؟';
        setTimeout(() => { btn.classList.remove('armed'); btn.textContent = '🗑'; }, 2600);
        return;
      }
      SESSIONS = SESSIONS.filter((x) => x.id !== s.id);
      EXPANDED.delete(s.id);
      await chrome.storage.local.set({ sessions: SESSIONS });
      render();
      flash('المجموعة اتمسحت');
      return;
    }

    if (act === 'rmtab') {
      const row = btn.closest('.tabrow');
      const u = row && row.dataset.url;
      const i = s.tabs.findIndex((t) => t.url === u);
      if (i > -1) {
        s.tabs.splice(i, 1);
        await chrome.storage.local.set({ sessions: SESSIONS });
        if (!s.tabs.length && s.id !== 'inbox') SESSIONS = SESSIONS.filter((x) => x.id !== s.id);
        render();
      }
      return;
    }

    if (act === 'ren') {
      e.stopPropagation();
      const nameEl = sec.querySelector('.s-name');
      if (nameEl.querySelector('input')) return;
      const old = s.name;
      nameEl.innerHTML = `<input value="${esc(old)}">`;
      const inp = nameEl.querySelector('input');
      inp.focus(); inp.select();
      const commit = async () => {
        const v = inp.value.trim() || old;
        s.name = v;
        await chrome.storage.local.set({ sessions: SESSIONS });
        render();
      };
      inp.addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter') { ev.preventDefault(); inp.blur(); }
        if (ev.key === 'Escape') { inp.value = old; inp.blur(); }
      });
      inp.addEventListener('blur', commit, { once: true });
      return;
    }
  }

  // تاب مفرد: فتح بالضغط
  const row = e.target.closest('.tabrow');
  if (row) {
    try { await chrome.tabs.create({ url: row.dataset.url, active: true }); } catch (err) {}
    return;
  }

  // طي/فتح المجموعة
  if (e.target.closest('.s-head')) {
    if (EXPANDED.has(s.id)) EXPANDED.delete(s.id); else EXPANDED.add(s.id);
    render();
  }
});

/* لو صورة الفافيكون فشلت → الحرف البديل يبان (CSP آمن) */
document.addEventListener('error', (e) => {
  if (e.target && e.target.tagName === 'IMG') e.target.remove();
}, true);

/* ── البحث ── */
$('#search').addEventListener('input', (e) => { FILTER = e.target.value; render(); });

/* ── تشغيل ── */
(async () => {
  const data = await chrome.storage.local.get('sessions');
  SESSIONS = data.sessions || [];
  render();
  try {
    const tabs = await chrome.tabs.query({});
    $('#openCount').textContent = 'مفتوحين دلوقتي: ' + tabs.length + ' تاب';
  } catch (e) {}
})();
