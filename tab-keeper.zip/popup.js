/* حافظ التابات v2 — منطق البوب أب / اللوحة الجانبية */
const $ = (s, el = document) => el.querySelector(s);
let SESSIONS = [];
let EXPANDED = new Set();   // مجموعات مفتوحة
let FORMS = new Set();      // مجموعات بفورم إضافة لينك مفتوحة
let RENAMING = new Set();   // مجموعات في وضع تعديل الاسم
let CHOOSER = null;         // {tab} — اختيار مجموعة لحفظ التاب الحالي
let FILTER = '';
let DRAG = null;            // {url, fromId} — تاب بيتسحب جوه اللوحة
let JUST_DRAGGED = 0;       // منع فتح التاب بعد السحب

const COLORS = ['#2BD4A8', '#E3B94E', '#5BC0EB', '#F4845F', '#9B8CE8', '#F26D9B', '#4ECDC4', '#A8D96F'];
const nextColor = () => COLORS[SESSIONS.length % COLORS.length];

const esc = (t) => (t || '').replace(/[&<>"']/g, (c) => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[c]));

const host = (u) => {
  try { return new URL(u).hostname.replace(/^www\./, ''); } catch (e) { return (u || '').slice(0, 42); }
};

function fmtDate(ts) {
  const d = new Date(ts);
  const day = d.toLocaleDateString('ar-EG', { day: 'numeric', month: 'long' });
  const time = d.toLocaleTimeString('ar-EG', { hour: 'numeric', minute: '2-digit' });
  return day + ' · ' + time;
}

function normalizeUrl(u) {
  u = (u || '').trim();
  if (!u) return '';
  if (!/^[a-z][a-z0-9+.-]*:/i.test(u)) u = 'https://' + u;
  try {
    const x = new URL(u);
    return /^https?:$/.test(x.protocol) ? x.href : '';
  } catch (e) { return ''; }
}

/* ── التقاط التابات المفتوحة ── */
async function captureOpenTabs() {
  const tabs = await chrome.tabs.query({});
  const seen = new Set(); const saved = []; const ids = [];
  for (const t of tabs) {
    const u = t.url || t.pendingUrl || '';
    if (!/^(https?|file):/i.test(u)) continue;
    if (seen.has(u)) continue; seen.add(u);
    saved.push({ title: t.title || u, url: u, favIconUrl: /^https?:/i.test(t.favIconUrl || '') ? t.favIconUrl : '' });
    ids.push(t.id);
  }
  return { saved, ids };
}

/* ── الرسم ── */
function render() {
  const list = $('#sessions');
  const q = FILTER.trim().toLowerCase();
  const parts = [];

  if (CHOOSER) {
    parts.push(`
    <div class="chooser">
      <div class="c-meta"><b>احفظ التاب:</b><span>${esc((CHOOSER.tab.title || CHOOSER.tab.url).slice(0, 46))}</span></div>
      <select id="chooseTarget">
        ${SESSIONS.map((s) => `<option value="${s.id}">${esc(s.name)} (${s.tabs.length})</option>`).join('')}
        <option value="__new__">➕ مجموعة جديدة</option>
      </select>
      <button class="mini go" data-act="choosesave">حفظ</button>
      <button class="mini" data-act="choosecancel">إلغاء</button>
    </div>`);
  }

  let shown = 0;
  parts.push(SESSIONS.map((s) => {
    const tabs = s.tabs.filter((t) =>
      !q || (t.title || '').toLowerCase().includes(q) || (t.url || '').toLowerCase().includes(q));
    if (q && !tabs.length) return '';
    shown++;
    const open = EXPANDED.has(s.id);
    const c = s.color || COLORS[0];
    return `
    <section class="session ${open ? 'open' : ''}" data-id="${s.id}" style="--c:${c}">
      <div class="s-head">
        <span class="chev">▾</span>
        <button class="dot" data-act="color" title="غيّر لون المجموعة"></button>
        ${RENAMING.has(s.id)
          ? `<div class="s-name"><input value="${esc(s.name)}"></div>`
          : `<div class="s-name">${esc(s.name)}</div>`}
        <span class="count">${s.tabs.length} تاب</span>
        <div class="s-actions">
          <button class="mini pin" data-act="pin" title="⚡ دوس مرة: الصفحة اللي انت فيها تتسجل هنا فورًا">⚡</button>
          <button class="mini add" data-act="add" title="ضيف التابات المفتوحة دلوقتي للمجموعة دي">+</button>
          <button class="mini link" data-act="addlink" title="ضيف لينك بنفسك">🔗</button>
          <button class="mini ren" data-act="ren" title="غيّر الاسم">✎</button>
          <button class="mini del" data-act="del" title="امسح المجموعة">🗑</button>
        </div>
      </div>
      <div class="s-date">${fmtDate(s.created)}</div>
      <div class="s-tabs">
        <button class="openall-bar" data-act="openall">▶ افتح كل تابات المجموعة (${s.tabs.length})</button>
        ${FORMS.has(s.id) ? `
        <div class="addform">
          <input class="f-url" placeholder="اللينك — مثلًا khamsat.com أو الصق أي لينك">
          <input class="f-title" placeholder="الاسم اللي يظهر (اختياري)">
          <div class="f-row">
            <button class="mini go" data-act="formsave">أضف</button>
            <button class="mini" data-act="formcancel">إلغاء</button>
          </div>
        </div>` : ''}
        ${tabs.map((t) => `
          <div class="tabrow" draggable="true" data-url="${esc(t.url)}" title="دوس لفتح التاب · أو اسحبه لمجموعة تانية">
            <span class="favw">${t.favIconUrl ? `<img src="${esc(t.favIconUrl)}" alt="">` : ''}<i>${esc((t.title || '؟').trim()[0] || '؟')}</i></span>
            <div class="tmeta">
              <div class="ttitle">${esc(t.title || t.url)}</div>
              <div class="thost">${esc(host(t.url))}</div>
            </div>
            <button class="mini x" data-act="rmtab" title="شيله من المجموعة">✕</button>
          </div>`).join('')}
        ${tabs.length ? '' : '<div class="notabs">المجموعة فاضية — اسحب أي لينك وارميه هنا 🖱<br>أو 🔗 اكتبه · أو ⚡ احفظ الصفحة الحالية</div>'}
      </div>
    </section>`;
  }).join(''));

  if (!shown) {
    parts.push(q
      ? `<div class="empty">مفيش نتيجة للبحث «${esc(FILTER)}»</div>`
      : `<div class="empty">🗂️ مفيش أي حاجة محفوظة لسه<br><small>دوس «احفظ كل التابات» أو «➕ مجموعة جديدة» وابدأ صنّف بنفسك</small></div>`);
  }

  list.innerHTML = parts.join('');

  // ربط إدخال تعديل الاسم
  for (const id of RENAMING) {
    const s = SESSIONS.find((x) => x.id === id);
    const inp = list.querySelector(`.session[data-id="${id}"] .s-name input`);
    if (s && inp) attachRename(s, inp);
  }
}

/* ── تعديل الاسم ── */
function attachRename(s, inp) {
  const old = s.name;
  inp.focus(); inp.select();
  const commit = async () => {
    s.name = inp.value.trim() || old;
    RENAMING.delete(s.id);
    await chrome.storage.local.set({ sessions: SESSIONS });
    render();
  };
  inp.addEventListener('keydown', (ev) => {
    if (ev.key === 'Enter') { ev.preventDefault(); inp.blur(); }
    if (ev.key === 'Escape') { inp.value = old; inp.blur(); }
  });
  inp.addEventListener('blur', commit, { once: true });
}

/* ── Toast ── */
let toastTimer = null;
function flash(msg) {
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2300);
}

const save = () => chrome.storage.local.set({ sessions: SESSIONS });

/* ── أزرار الشريط ── */
$('#saveAll').addEventListener('click', async () => {
  const { saved, ids } = await captureOpenTabs();
  if (!saved.length) { flash('مفيش تابات مواقع أقدر أحفظها'); return; }
  const s = { id: 's' + Date.now(), name: 'جلسة ' + fmtDate(Date.now()), created: Date.now(), color: nextColor(), tabs: saved };
  SESSIONS.unshift(s);
  EXPANDED.add(s.id);
  await save();
  if ($('#closeAfter').checked && ids.length) {
    try {
      await chrome.tabs.create({ active: false });
      await chrome.tabs.remove(ids);
    } catch (e) { /* لو البوب أب اتقفل، الحفظ اتم قبل كده */ }
  }
  render();
  flash(`تم حفظ ${saved.length} تاب — المتصفح بقى نضيف`);
});

$('#newGroup').addEventListener('click', async () => {
  const s = { id: 's' + Date.now(), name: 'مجموعة جديدة', created: Date.now(), color: nextColor(), tabs: [] };
  SESSIONS.unshift(s);
  EXPANDED.add(s.id);
  RENAMING.add(s.id);
  await save();
  render();
});

$('#saveCurrent').addEventListener('click', async () => {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  const u = (t && (t.url || t.pendingUrl)) || '';
  if (!/^https?:/i.test(u)) { flash('التاب ده مش موقع عادي'); return; }
  CHOOSER = { tab: { title: t.title || u, url: u, favIconUrl: /^https?:/i.test(t.favIconUrl || '') ? t.favIconUrl : '' } };
  render();
  const sel = $('#chooseTarget');
  if (sel) sel.focus();
});

/* ── حفظ الصفحة الحالية في مجموعة محددة فورًا ── */
async function grabCurrentTab() {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  const u = (t && (t.url || t.pendingUrl)) || '';
  if (!/^https?:/i.test(u)) return null;
  return { title: t.title || u, url: u, favIconUrl: /^https?:/i.test(t.favIconUrl || '') ? t.favIconUrl : '' };
}

/* ── تفاعلات القايمة ── */
$('#sessions').addEventListener('click', async (e) => {
  if (Date.now() - JUST_DRAGGED < 300) return; // متفتحش التاب اللي لسه مسحوب
  const btn = e.target.closest('[data-act]');
  const sec = e.target.closest('.session');

  // أزرار الشووزر (خارج المجموعات)
  if (btn && (btn.dataset.act === 'choosesave' || btn.dataset.act === 'choosecancel')) {
    if (btn.dataset.act === 'choosecancel') { CHOOSER = null; render(); return; }
    const sel = $('#chooseTarget');
    const v = sel ? sel.value : '__new__';
    if (v === '__new__') {
      const s = { id: 's' + Date.now(), name: 'مجموعة جديدة', created: Date.now(), color: nextColor(), tabs: [CHOOSER.tab] };
      SESSIONS.unshift(s);
      EXPANDED.add(s.id);
      RENAMING.add(s.id);
    } else {
      const s = SESSIONS.find((x) => x.id === v);
      if (s) {
        if (!s.tabs.some((t) => t.url === CHOOSER.tab.url)) s.tabs.unshift(CHOOSER.tab);
        EXPANDED.add(s.id);
      }
    }
    CHOOSER = null;
    await save();
    render();
    flash('اتحفظ التاب');
    return;
  }

  if (!sec) return;
  const s = SESSIONS.find((x) => x.id === sec.dataset.id);
  if (!s) return;
  const act = btn ? btn.dataset.act : null;

  if (act === 'openall') {
    for (const t of s.tabs) {
      try { await chrome.tabs.create({ url: t.url, active: false }); } catch (err) {}
    }
    flash(`فتحت ${s.tabs.length} تاب`);
    return;
  }

  if (act === 'pin') {
    const item = await grabCurrentTab();
    if (!item) { flash('التاب ده مش موقع عادي'); return; }
    const dup = s.tabs.some((t) => t.url === item.url);
    if (!dup) s.tabs.unshift(item);
    EXPANDED.add(s.id);
    await save();
    render();
    flash(dup ? 'الصفحة دي محفوظة هنا من قبل كده' : `⚡ اتحفظ في «${s.name}»`);
    return;
  }

  if (act === 'add') {
    const { saved } = await captureOpenTabs();
    const have = new Set(s.tabs.map((t) => t.url));
    let added = 0;
    for (const t of saved) {
      if (!have.has(t.url)) { s.tabs.push(t); have.add(t.url); added++; }
    }
    await save();
    EXPANDED.add(s.id);
    render();
    flash(added ? `ضفت ${added} تاب جديد للمجموعة` : 'مفيش تابات جديدة تتضاف');
    return;
  }

  if (act === 'addlink') {
    FORMS.has(s.id) ? FORMS.delete(s.id) : FORMS.add(s.id);
    EXPANDED.add(s.id);
    render();
    return;
  }

  if (act === 'formcancel') { FORMS.delete(s.id); render(); return; }

  if (act === 'formsave') {
    const form = btn.closest('.addform');
    const url = normalizeUrl(form.querySelector('.f-url').value);
    if (!url) { flash('اللينك مش مظبوط'); return; }
    const title = form.querySelector('.f-title').value.trim() || url;
    if (!s.tabs.some((t) => t.url === url)) {
      s.tabs.unshift({ title, url, favIconUrl: '' });
      await save();
    }
    FORMS.delete(s.id);
    EXPANDED.add(s.id);
    render();
    flash('اتضاف اللينك');
    return;
  }

  if (act === 'color') {
    s.color = COLORS[(COLORS.indexOf(s.color || COLORS[0]) + 1) % COLORS.length];
    await save();
    render();
    return;
  }

  if (act === 'ren') {
    RENAMING.add(s.id);
    render();
    return;
  }

  if (act === 'del') {
    if (!btn.classList.contains('armed')) {
      btn.classList.add('armed');
      btn.textContent = 'متأكد؟';
      setTimeout(() => { btn.classList.remove('armed'); btn.textContent = '🗑'; }, 2600);
      return;
    }
    SESSIONS = SESSIONS.filter((x) => x.id !== s.id);
    EXPANDED.delete(s.id);
    FORMS.delete(s.id);
    RENAMING.delete(s.id);
    await save();
    render();
    flash('المجموعة اتمسحت');
    return;
  }

  if (act === 'rmtab') {
    const row = btn.closest('.tabrow');
    const u = row && row.dataset.url;
    const i = s.tabs.findIndex((t) => t.url === u);
    if (i > -1) {
      s.tabs.splice(i, 1);
      await save();
      render();
    }
    return;
  }

  // تاب مفرد: فتح بالضغط
  const row = e.target.closest('.tabrow');
  if (row) {
    try { await chrome.tabs.create({ url: row.dataset.url, active: true }); } catch (err) {}
    return;
  }

  // طي/فتح المجموعة
  if (e.target.closest('.s-head')) {
    if (EXPANDED.has(s.id)) EXPANDED.delete(s.id); else EXPANDED.add(s.id);
    render();
  }
});

/* ── السحب والإفلات ──
   1) اسحب لينك من أي موقع وارميه على أي مجموعة → يتضاف
   2) اسحب تاب محفوظ من مجموعة لمجموعة تانية → يتنقل */
$('#sessions').addEventListener('dragstart', (e) => {
  const row = e.target.closest('.tabrow');
  if (!row) return;
  const sec = row.closest('.session');
  DRAG = { url: row.dataset.url, fromId: sec ? sec.dataset.id : null };
  try {
    e.dataTransfer.effectAllowed = 'copyMove';
    e.dataTransfer.setData('text/uri-list', row.dataset.url);
    e.dataTransfer.setData('text/plain', row.dataset.url);
    e.dataTransfer.setData('application/x-tk', JSON.stringify(DRAG));
  } catch (err) {}
  row.classList.add('dragging');
});

$('#sessions').addEventListener('dragend', (e) => {
  const row = e.target.closest('.tabrow');
  if (row) row.classList.remove('dragging');
  DRAG = null;
  JUST_DRAGGED = Date.now();
  clearDropMarks();
});

function clearDropMarks() {
  for (const el of document.querySelectorAll('.drop-move,.drop-link'))
    el.classList.remove('drop-move', 'drop-link');
}

$('#sessions').addEventListener('dragover', (e) => {
  const sec = e.target.closest('.session');
  if (!sec) return;
  let types = [];
  try { types = [...e.dataTransfer.types]; } catch (err) {}
  if (!types.includes('text/uri-list') && !types.includes('application/x-tk')) return;
  if (DRAG && DRAG.fromId === sec.dataset.id) return; // نفس المجموعة
  e.preventDefault();
  try { e.dataTransfer.dropEffect = DRAG ? 'move' : 'copy'; } catch (err) {}
  clearDropMarks();
  sec.classList.add(DRAG ? 'drop-move' : 'drop-link');
});

$('#sessions').addEventListener('dragleave', (e) => {
  const sec = e.target.closest('.session');
  if (sec) sec.classList.remove('drop-move', 'drop-link');
});

$('#sessions').addEventListener('drop', async (e) => {
  const sec = e.target.closest('.session');
  if (!sec) return;
  const s = SESSIONS.find((x) => x.id === sec.dataset.id);
  if (!s) return;
  e.preventDefault();
  clearDropMarks();

  // 1) نقل تاب محفوظ من مجموعة لمجموعة
  let internal = null;
  try { internal = JSON.parse(e.dataTransfer.getData('application/x-tk') || 'null'); } catch (err) {}
  if (internal && internal.url) {
    const from = SESSIONS.find((x) => x.id === internal.fromId);
    if (from && from.id !== s.id) {
      const i = from.tabs.findIndex((t) => t.url === internal.url);
      if (i > -1) {
        const [item] = from.tabs.splice(i, 1);
        if (!s.tabs.some((t) => t.url === item.url)) s.tabs.unshift(item);
        EXPANDED.add(s.id);
        await save();
        render();
        flash(`اتنقل لـ «${s.name}»`);
      }
    }
    return;
  }

  // 2) لينك مسحوب من صفحة ويب
  const raw = e.dataTransfer.getData('text/uri-list') || e.dataTransfer.getData('text/plain') || '';
  const url = normalizeUrl(raw.split('\n')[0].trim());
  if (!url) { flash('اللي مسحبه مش لينك صالح'); return; }
  let title = '';
  const html = e.dataTransfer.getData('text/html');
  if (html) {
    const m = html.match(/<a[^>]*>([\s\S]*?)<\/a>/i);
    if (m) title = m[1].replace(/<[^>]+>/g, '').trim();
  }
  const dup = s.tabs.some((t) => t.url === url);
  if (!dup) s.tabs.unshift({ title: title || url, url, favIconUrl: '' });
  EXPANDED.add(s.id);
  await save();
  render();
  flash(dup ? 'اللينك ده موجود هنا بالفعل' : `🖱 اللينك اتضاف لـ «${s.name}»`);
});

/* لو صورة الفافيكون فشلت → الحرف البديل يبان */
document.addEventListener('error', (e) => {
  if (e.target && e.target.tagName === 'IMG') e.target.remove();
}, true);

/* ── البحث ── */
$('#search').addEventListener('input', (e) => { FILTER = e.target.value; render(); });

/* ── تشغيل ── */
(async () => {
  const data = await chrome.storage.local.get('sessions');
  SESSIONS = data.sessions || [];
  // ترحية: جلسات قديمة من غير لون
  SESSIONS.forEach((s, i) => { if (!s.color) s.color = COLORS[i % COLORS.length]; });
  // كشف وضع اللوحة الجانبية (البوب أب عمده أقصى 600px)
  if (window.innerHeight > 620 || window.innerWidth > 500) document.body.classList.add('panel-mode');
  render();
  try {
    const tabs = await chrome.tabs.query({});
    $('#openCount').textContent = 'مفتوحين دلوقتي: ' + tabs.length + ' تاب';
  } catch (e) {}
  flash('جديد 2.1: اسحب أي لينك وارميه في أي مجموعة 🖱');
})();
